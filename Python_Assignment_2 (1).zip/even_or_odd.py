# even_or_odd.py

# Take input from user
try:
    number = int(input("Enter an integer: "))
    if number % 2 == 0:
        print(f"{number} is Even.")
    else:
        print(f"{number} is Odd.")
except ValueError:
    print("Invalid input! Please enter a valid integer.")