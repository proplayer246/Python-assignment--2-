# sum_1_to_50.py

# Initialize sum
total = 0

# Loop through 1 to 50
for num in range(1, 51):
    total += num

# Display result
print("Sum of numbers from 1 to 50 is:", total)