# Python Assignment 2: Control Structures

This repository contains two Python programs based on control structures from Module 3.

## Task 1: Even or Odd Checker
- Prompts the user to input an integer.
- Uses `if-else` to determine if the number is even or odd.
- Displays the result.

### Example Output:
```
Enter an integer: 7
7 is Odd.
```

## Task 2: Sum of Numbers from 1 to 50
- Uses a `for` loop to iterate through numbers from 1 to 50.
- Calculates and displays the total sum.

### Example Output:
```
Sum of numbers from 1 to 50 is: 1275
```

## How to Run:
1. Clone or download this repository.
2. Run each `.py` file using Python 3.
3. Make sure to test both programs with different inputs.